// VISUAL & MOTION DESIGN : GAL SHIR
// https://dribbble.com/shots/4532056-Alien-Invasion

// WEB ANIMATION : KONO
// https://twitter.com/konoanimation
// http://kono.co.za/
// hi@kono.co.za

// No JS
// No plugins
// 45KB size